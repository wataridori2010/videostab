//
//  main.c
//  klt
//
//  Created by Ito Yuichi on 2017/06/17.
//  Copyright © 2017年 Ito Yuichi. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
