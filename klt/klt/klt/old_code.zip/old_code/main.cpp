// main.cpp : Defines the entry point for the console application.
//

#include <stdio.h>  // printf

extern "C" {
	void RunExample1();
	void RunExample2();
	void RunExample3();
	void RunExample4();
	void RunExample5();
}

int main(int argc, char* argv[])
{
	// select which example to run here
	const int which = 1;

    RunExample1();

	return 0;
}

