/*********************************************************************
 * storeFeatures.c
 *
 *********************************************************************/

/* Our includes */
#include "klt.h"


/*********************************************************************
 *
 */

void KLTStoreFeatureList(
  KLT_FeatureList fl,
  KLT_FeatureTable ft,
  int frame)
{
  int feat;
  for (feat = 0 ; feat < fl->nFeatures ; feat++)  {
    ft->feature[feat][frame]->x   = fl->feature[feat]->x;
    ft->feature[feat][frame]->y   = fl->feature[feat]->y;
    ft->feature[feat][frame]->val = fl->feature[feat]->val;
  }
}


/*********************************************************************
 *
 */

void KLTExtractFeatureList(
  KLT_FeatureList fl,
  KLT_FeatureTable ft,
  int frame)
{
  int feat;

  for (feat = 0 ; feat < fl->nFeatures ; feat++)  {
    fl->feature[feat]->x   = ft->feature[feat][frame]->x;
    fl->feature[feat]->y   = ft->feature[feat][frame]->y;
    fl->feature[feat]->val = ft->feature[feat][frame]->val;
  }
}
 

/*********************************************************************
 *
 */

void KLTStoreFeatureHistory(
  KLT_FeatureHistory fh,
  KLT_FeatureTable ft,
  int feat)
{
  int frame;

  for (frame = 0 ; frame < fh->nFrames ; frame++)  {
    ft->feature[feat][frame]->x   = fh->feature[frame]->x;
    ft->feature[feat][frame]->y   = fh->feature[frame]->y;
    ft->feature[feat][frame]->val = fh->feature[frame]->val;
  }
}


/*********************************************************************
 *
 */

void KLTExtractFeatureHistory(
  KLT_FeatureHistory fh,
  KLT_FeatureTable ft,
  int feat)
{
  int frame;

  for (frame = 0 ; frame < fh->nFrames ; frame++)  {
    fh->feature[frame]->x   = ft->feature[feat][frame]->x;
    fh->feature[frame]->y   = ft->feature[feat][frame]->y;
    fh->feature[frame]->val = ft->feature[feat][frame]->val;
  }
}

